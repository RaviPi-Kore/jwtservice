/*
 * node-cache 4.1.1 ( 2018-01-31 )
 * https://github.com/mpneuried/nodecache
 *
 * Released under the MIT license
 * https://github.com/mpneuried/nodecache/blob/master/LICENSE
 *
 * Maintained by  (  )
*/
(function() {
  var exports;

  exports = module.exports = require('./lib/node_cache');

  exports.version = '4.1.1';

}).call(this);
